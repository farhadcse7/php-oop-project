<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Single Product</title>
</head>
<h1>Single Product Details</h1>
<h1>Mango</h1>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Autem cupiditate dignissimos esse fuga fugiat labore, magnam minima minus mollitia nam odio, pariatur perferendis placeat quidem quis quod quos ullam velit.</p>
<body>

</body>
</html>


