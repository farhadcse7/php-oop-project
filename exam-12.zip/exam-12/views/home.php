<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<table border="1px solid yellow" width="600px">
    <thead>
    <th>id</th>
    <th>name</th>
    <th>price</th>
    <th>description</th>
    <th>Image</th>
    <th>Details</th>
    <th> <select>
            <?php foreach ($categories as $category) { ?>
            <option value=""><?php echo $category; ?></option>
            <?php } ?>
        </select></th>

    </thead>
    <?php foreach ($products as $product) { ?>
        <tbody>
        <td><?php echo $product['id']; ?></td>
        <td><?php echo $product['name']; ?></td>
        <td><?php echo $product['price']; ?></td>
        <td><?php echo $product['description']; ?></td>
        <td><img src="<?php echo $product['image']; ?>"/></td>
        <td><a href="views/singleproductdetail.php">Read More</a></td>
        <td></td>
        </tbody>
    <?php } ?>
</table>


</body>
</html>
