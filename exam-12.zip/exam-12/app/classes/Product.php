<?php


namespace App\classes;




class Product
{
    public $products=[];
    public function __construct()
    {
        $this->products=[
            0=>[
                "id"=>1,
                "name"=>"mango",
                "price"=>150,
                "description"=>"rajshahir mango",
                "image"=>"assets/img/1.jpeg"
            ],
            1=>[
                "id"=>2,
                "name"=>"apple",
                "price"=>250,
                "description"=>"bogurar apple",
                "image"=>"assets/img/2.jpeg"
            ],
            2=>[
                "id"=>3,
                "name"=>"lemon",
                "price"=>50,
                "description"=>"rajshahir lemon",
                "image"=>"assets/img/3.jpeg"
            ],
            3=>[
                "id"=>4,
                "name"=>"pineapple",
                "price"=>150,
                "description"=>"rajshahir pineapple",
                "image"=>"assets/img/4.jpeg"
            ],
        ];

    }

    public function returnProducts(){
        return $this->products;
    }

}