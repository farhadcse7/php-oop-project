<?php


namespace App\classes;
use App\classes\Product;
use App\classes\Category;



class Home
{
    public $product;
    public $products;
    public function index(){
        $this->product= new Product();
        $this->products=$this->product->returnProducts();

        $this->category= new Category();
        $this->categories=$this->category->returnCategory();

         return  view("home", ["products"=>$this->products, "categories"=>$this->categories]);

    }

}