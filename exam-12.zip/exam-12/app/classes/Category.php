<?php


namespace App\classes;


class Category
{
    public $categories=[];
    public function __construct()
    {
        $this->categories=[
            "fruit", "drinks", "vegetables"
        ];

    }

    public function returnCategory(){
        return $this->categories;
    }

}